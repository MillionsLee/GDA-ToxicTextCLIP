def generate_poisoned_text_of_beam_search(options_, logger_):

    # 1. load model
    model = models.load_my_model(options_)
    device = options_.device
    state_dict = torch.load(
        options.checkpoints_path, map_location=device, weights_only=False
    )["state_dict"]
    model.load_state_dict(state_dict)
    model.eval().to(device)

    # 2. initialization
    pure_tokenize = Tokenizer()
    image_path = options_.image_path
    clean_text = options_.clean_text_from_data
    poisoned_text_ = clean_text
    logger_.info(f'Clean text:"{clean_text}"')

    category_embedding = options_.category_embeddings[options_.clean_class.strip().lower()]
    category_embedding = category_embedding.unsqueeze(0).to(device)


    image = model.image_preprocess(Image.open(image_path)).unsqueeze(0).to(device)

    image_feature, image_representation = model.clip_model.encode_image(
        image, return_image_represent=True
    )

    image_cls = image_representation[:, 0, :]
    image_representation = image_representation[:, 1:, :]
    image_representation = image_representation.to(torch.float32)
    # add cls to representations 
    image_cls = image_cls.to(torch.float32)
    image_cls = image_cls @ model.text_decoder.projection_modify_visual_scale

    results_poisoned_text = []
    haveAddPoisonedText = set()  # Record whether the poisoned text has been added to the list before. If it has been added, it will no longer be included

    haveUsedPoisonedText = set()
    averageSimilarity = 0  
    # beam_search parms
    options_.forced_bos_token_id = None
    options_.no_repeat_ngram = max(2,len(options_.clean_class.split()))

    logits_processor = _get_logits_processor(options_)
    lambdaAdd = 1
    iterate_num = 1
    while iterate_num < 30:
        if poisoned_text_ in haveUsedPoisonedText:
            lambdaAdd -= 0.1
            if lambdaAdd < 0:
                break
        else:
            lambdaAdd = 1

            haveUsedPoisonedText.add(poisoned_text_)


        logger_.info(f'Iteration {iterate_num} poisoned text:"{poisoned_text_}"')
        poisoned_text_token = clip.tokenize(poisoned_text_).to(device)
        # poisoned text feature
        poisoned_text_feature = model.clip_model.encode_text(poisoned_text_token)
        # getsrc_representations_batch
        poisoned_text_feature = poisoned_text_feature.to(torch.float32)
        src_representations_batch = model.process_src_representations_batch(
            image_representations_batch=image_representation,
            text_feature=poisoned_text_feature,
        )

        src_representations_batch[:, -1, :] += lambdaAdd * image_cls

        # decode
        predicted_sentences = group_beam_search_generate(
            model=model,
            src_representations_batch=src_representations_batch,
            logits_processor=logits_processor,
            max_length=40,
            num_beams=options.num_beams,
            output_num_return_sequences_per_batch=options_.get_sequences_num,
            num_beam_groups = options_.num_beam_groups,
            length_penalty = 1,

        )

        # get poisoned text
        decodePoisonedTextResults = []
        for sentence in predicted_sentences:
            # Convert tensor to list for easier processing
            sentence = sentence.tolist()
            bos_index = sentence.index(BOS_TOKEN_ID)
            # Check if the sentence contains the end token
            if EOS_TOKEN_ID in sentence:
                end_index = sentence.index(EOS_TOKEN_ID)
                # Extract tokens between start and end tokens (inclusive)
                sentence = sentence[bos_index + 1 : end_index]
            else:
                # Extract tokens after the start token
                sentence = sentence[bos_index + 1 :]

            decodePoisonedTextResults.append(pure_tokenize.decode(sentence))

        # sim
        text = clip.tokenize(decodePoisonedTextResults).to(device)
        # logits_per_image, logits_per_text = model.clip_model(image, text)
        text_embedding = model.clip_model.encode_text(text)

        logits_per_image, logits_per_text = get_distance(category_embedding, text_embedding)
        logits_per_image = logits_per_image[0].tolist()

        curr_poisoned_text_list = list(zip(logits_per_image, decodePoisonedTextResults))
        # sort
        curr_poisoned_text_list.sort(reverse=True)
        addNewPoisonedTextFlag = False
        for sentence in curr_poisoned_text_list:

            if (
                sentence[1] not in haveAddPoisonedText and check_sentence(options_,sentence[1])
            ):
                # if sentence[1] not in haveAddPoisonedText:
                haveAddPoisonedText.add(sentence[1])
                results_poisoned_text.append(sentence)
                addNewPoisonedTextFlag = True
        if addNewPoisonedTextFlag:
            results_poisoned_text.sort(reverse=True, key=lambda x: x[0])

            # results_poisoned_text = results_poisoned_text[: options_.get_sequences_num]
            # averageSimilarity = round(sum(item[0] for item in results_poisoned_text) / len(
            #     results_poisoned_text
            # ),5)
        if not addNewPoisonedTextFlag or lambdaAdd < 0.1:

            indexList = list(range(min(math.ceil(options_.get_sequences_num // 10),math.ceil(len(results_poisoned_text) // 10))))
            random.shuffle(indexList)
            for index in indexList:
                if results_poisoned_text[index][1] not in haveUsedPoisonedText:
                    poisoned_text_ = results_poisoned_text[index][1]
                    break
        iterate_num += 1


    return results_poisoned_text
