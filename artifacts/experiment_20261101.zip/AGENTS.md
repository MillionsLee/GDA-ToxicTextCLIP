# 实验默认配置（用户于 2026-10-24 指定）

后续实验默认沿用第一次复现配置，即截图中 ToxicTextCLIP W-BD 的 Hit@1/5/10 为 16.66% / 53.68% / 72.73% 的历史实验。不要默认采用 four_arm_20261024 的修改版协议。用户后续明确要求的实验变量优先。

## 固定参考与训练数据

- 首次快照：`research_20261013/user_snapshot/`。
- 原方法对照直接复用快照中 `wbd_data/victim/attack_train_wbd_100k.csv`，SHA256：`007723441ebe295c382b66057b533b0823b49f35b3058a0f704032c5e59283b8`；不要以重新生成的文本替代该对照。
- No Attack、W-BD Baseline 分别使用同目录 `clean_train_100k.csv`、`attack_train_wbd_baseline_100k.csv`。
- 干净数据100000条，攻击组额外100条投毒，目标boat，触发器zx，20张目标图像，每张5条。改进方法只改变用户指定的变量，保持其余条件一致并记录差异。

## 训练

- 使用首次 `wbd_data/victim/run_victim.py` 与作者 `src.main` 路径作为参考。
- RN50，随机初始化（pretrained=False），全参数训练；batch_size=32，num_workers=2。
- AdamW：lr=5e-5，betas=(0.9,0.999)，eps=1e-8，weight_decay=0.1；沿用作者参数分组。
- 名义10轮余弦调度，warmup=10000，保留作者调度 step 语义；主比较固定为epoch_4.pt。缩短执行轮数时也不能改成4轮调度。
- cross_aug=False，memory_bank=False，RoCLIP_switch=False。
- 首次入口 cuDNN benchmark=True、deterministic=False；未找到显式固定训练种子的记录，也未取得首次初始权重与随机状态。不要把生成seed42误写成首次训练seed42，不要声称可以逐位恢复首次训练或保证同样分数。
- 后续若引入固定训练种子、逐轮重设种子、独立DataLoader generator或确定性设置，必须明确记录为相对首次的协议变动，不得静默切换。

## 需要重新生成文本时

- 沿用首次 `wbd_data/nonboat20/run_decoder_200.py`，遍历全部200个来源，生成400条候选；不先缩减为160个来源/320条候选。
- 生成seed42在开始时设置，不能静默改成逐来源seed42+source_id。
- 增强器epoch_14.pth；ViT-B/32，image_as_context；每来源2条，num_beams=60，get_sequences_num=60，num_beam_groups=5，diversity_penalty=0.6，do_sample=True，top_k=60，top_p=0.9，temperature=1.5，pad_token_id=400。
- 首次最终候选、入库文本以快照 `final_candidates_db.csv`、`prepare_for_attack_texts.csv` 为准；不要把新选择器视为已认证的首次完整筛选流程。

## 评估与报告

- 沿用首次 `wbd_data/eval/eval_wbd_epoch4.py` 与 `eval_ca_epoch4.py` 的计算方式；隔离输出，保留历史结果。
- 主Hit@K使用带zx触发器的5779条查询，目标boat，固定第4轮。记录实际查询/图库哈希；旧实际图库缺少哈希，不能宣称已逐项认证一致。
- 截图CA是batch_size=512的批内图文配对准确率，不是论文零样本分类CA，也不是Clean Recall。
- 先检查是否恢复原方法相对Baseline的优势，再解释改进方法；多因素改变不能归因于单一模块。
- 用户此次要求是设置后续默认配置，并未要求立即启动新的GPU训练。
