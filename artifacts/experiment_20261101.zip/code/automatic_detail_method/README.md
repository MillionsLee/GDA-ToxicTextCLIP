# 按用户原始思路实现的自动细节方法

这是2026-10-27新建的独立实现。此前`reviewed_control_01`四条替换、`postfilter_01`五条替换都依赖AI看图核验，**不是本方法的结果**，不再用于声称本方法已验证。

本实现使用作者原有CLIP和解码器，不调用LLM、VLM、Florence，不接受AI核验名单、人工caption或图像特例。固定的类别别名/停用词是全数据通用规则。模型相似度只是自动接地代理，不是事实真值。

## 与用户方案逐项对应

1. **类别遮蔽和句内贡献**：先从文本移除类别名、词形和声明的别名。在剩余文本上贪心删除最多`eta`个词，每步最大化`cos(I,E(S))-cos(c,E(S))`，收益非正时停止，得到`S*`。随后在`S*`上做leave-one-out：

   `delta_I(w) = cos(I,E(S*)) - cos(I,E(S*\w))`

   `delta_c(w) = margin_c(S*) - margin_c(S*\w)`

   `d(w) = delta_I(w) - delta_c(w)`

   其中`margin_c(S)=cos(E(S),c)-max_{j!=c}cos(E(S),c_j)`，使用全部类别质心。也可显式选择全部类别softmax概率作为类别端指标。排除身份词、功能词、模板词，并要求`delta_I>0`及`d>0`；取最多`k`个词，按原句顺序组成`D`。这是句内删除贡献，不是单词与类别质心的相似度排序。

2. **Selector**：先检查`cos(I,E(S*)) >= threshold`，再仅按`cos(E(S*),c)`排序；没有额外叠加一次细节分数。原100条全部重新计算，同类候选与原文一起通过同一门槛后竞争5个名额。没有“每类最多改1条”的规则。候选不足时保留原文，并将未通过门槛但被保留的位置明确记为回退，不伪装成质量通过。

3. **增强器**：原`fT`、原生`lambdaAdd*imageCLS`和全部图像patch不变；在文本投影位置增加`lambda2*(f_detail @ linear_feature2eot)`。默认`f_detail=CLIP.encode_text(D)`，不把`fT`换成固定锚点。可显式选择`image_projection`：从所有来源自动提取的、剔除当前类别身份词的细节短语构成支撑集，按图像与这些短语的相似度做softmax加权文本嵌入。束搜索、作者类别检查与Jaccard保持原样，不另加AI事实门槛。

4. **离线迭代工具**：`core.coefficient_for_round`提供逐轮细节系数；`pool.merge_pool`保留来源图像与类别并合并文本池；`pool.bank_candidates`分别支持只用末轮或各轮候选。`run`入口目前协调一次离线生成/筛选；不把作者内部beam循环或受害模型训练轮数当作这项离线迭代。未运行多轮课程实验。

`eta=2,k=3,threshold=0.15,lambda2=0.1`是明确声明、尚未由独立开发验证选定的初始配置，不是最优参数或效果承诺。CLIP代理可能把抽象词或图片中的文字内容排到前面；遇到这种情况保留负例，不再用AI看图逐条修正名单。

## 统一调用入口

在安装了项目原依赖并拥有原图片/权重的远程环境中执行：

```bash
cd /home/million/ToxicTextCLIP_W-BD/wbd_data/iteration_20261027/code_auto
/home/million/miniconda3/envs/toxictextclip/bin/python -B -u -m automatic_detail_method run \
  --repo /home/million/ToxicTextCLIP_W-BD \
  --output /home/million/ToxicTextCLIP_W-BD/wbd_data/iteration_20261027/automatic_run_01 \
  --device cpu --eta 2 --detail-k 3 --grounding-threshold 0.15 \
  --detail-coefficient 0.1 --detail-mode loo
```

`--device`控制提取和selector；作者原生成阶段仍使用GPU。生成前检查GPU占用，有正常作业时拒绝重叠，不杀别的进程，不自动重试。输出目录必须全新。

`run`依次执行：全部200来源自动提取 → 原生参数生成400条 → 400条加200原caption、去重及128字符上限构成明确的新候选池 → 以首次100条为锚筛选替换并构建100100行训练CSV。每个阶段保存源码快照、输入/输出哈希和状态。它**不自动启动受害模型训练**。

仅调用selector、验证首次旧候选池，可执行：

```bash
/home/million/miniconda3/envs/toxictextclip/bin/python -B -u -m automatic_detail_method select \
  --repo /home/million/ToxicTextCLIP_W-BD \
  --candidates /home/million/ToxicTextCLIP_W-BD/wbd_data/nonboat20/final_candidates_db.csv \
  --output /home/million/ToxicTextCLIP_W-BD/wbd_data/iteration_20261027/automatic_selector_01 \
  --device cpu --eta 2 --detail-k 3 --grounding-threshold 0.15
```

这仅是selector调用，不代表增强器已重新生成400条。候选池来源在manifest里明确记录，不能把两种调用混为完整实验。

## 训练与报告边界

- 原方法对照保持首次CSV及SHA256`007723441ebe295c382b66057b533b0823b49f35b3058a0f704032c5e59283b8`，本实现只生成独立数据文件，不覆盖原数据。
- 构建训练集保留100000干净样本、100投毒数量、全部图像路径和行位置、20张boat图每图5条。用于计算接地的是文本生成来源图，最终投毒配对图仍是原boat图，不混淆二者。
- 后续训练走首次`run_victim/src.main`规则，RN50随机初始化、batch32、AdamW5e-5、名义10轮调度/10000warmup，主比较epoch4。生成seed42不当作训练seed42。
- 首次16.66/53.68/72.73只作历史参考；首次初始随机状态未知。正式比较需原CSV与本方法数据使用同一套记录过的初始权重/RNG，并报告这个配对措施。
- 最新单轮自动实验已完成：Hit@1/5/10=20.76/63.73/82.87%，相对复用作者组11.42/45.42/68.63提高；批内配对CA和干净Recall@10有下降。仅一个配对初始化，不声称稳定改善。详见`iteration_20261027/三组最终结果_20261027.md`。四条AI辅助替换的12.72/49.49/72.80仍不属于本方法。

主要文件：`core.py`（S*/D/selector）、`native.py`（加法条件和原生生成接口）、`cli.py`（统一入口和数据审计）、`pool.py`（离线轮次工具）。验证记录保存在`iteration_20261027/automatic_*`，不能将CPU条件接口通过表述为GPU完整束搜索已经通过。
